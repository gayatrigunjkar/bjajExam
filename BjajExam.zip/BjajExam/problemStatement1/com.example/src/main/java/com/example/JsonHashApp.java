package com.example;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.apache.commons.codec.digest.DigestUtils;

import java.io.File;
import java.io.IOException;
import java.util.Iterator;
import java.util.Map.Entry;

public class JsonHashApp {

    private static final int RANDOM_STRING_LENGTH = 8;
    private static final String FIXED_PRN_NUMBER = "240340120067";
    private static final String FIXED_RANDOM_STRING = "gayatri";

    public static void main(String[] args) {
        if (args.length != 1) {
            System.out.println("Usage: Md5(240340120067cdac_actsGayatri Gunjakar)");
            System.exit(1);
        }

        String jsonFilePath = args[0].trim();

        String destinationValue = findDestinationValue(jsonFilePath);
        if (destinationValue == null) {
            System.out.println("Key 'destination' not found in the JSON file.");
            System.exit(1);
        }

        // Use fixed PRN number and random string
        String prnNumber = FIXED_PRN_NUMBER;
        String randomString = FIXED_RANDOM_STRING;
        String concatenatedString = prnNumber + destinationValue + randomString;
        String md5Hash = DigestUtils.md5Hex(concatenatedString);

        // Output in the format: MD5_HASH(PRN Number + Destination Value + Random String);Random String
        System.out.println(md5Hash + ";" + randomString);
    }

    private static String findDestinationValue(String jsonFilePath) {
        ObjectMapper mapper = new ObjectMapper();
        try {
            JsonNode rootNode = mapper.readTree(new File(jsonFilePath));
            return findDestinationValueRecursive(rootNode);
        } catch (IOException e) {
            System.out.println("Error reading JSON file: " + e.getMessage());
            System.exit(1);
        }
        return null;
    }

    private static String findDestinationValueRecursive(JsonNode node) {
        if (node.isObject()) {
            for (Iterator<Entry<String, JsonNode>> it = node.fields(); it.hasNext(); ) {
                Entry<String, JsonNode> field = it.next();
                if (field.getKey().equals("destination")) {
                    return field.getValue().asText();
                }
                String result = findDestinationValueRecursive(field.getValue());
                if (result != null) {
                    return result;
                }
            }
        } else if (node.isArray()) {
            for (JsonNode arrayItem : node) {
                String result = findDestinationValueRecursive(arrayItem);
                if (result != null) {
                    return result;
                }
            }
        }
        return null;
    }
}
